import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import preact from "@preact/preset-vite";

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      plugins: [preact()],
      define: {
        'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
        'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY)
      },
      resolve: {
        alias: {
          '@': path.resolve(__dirname, '.'),
        }
      },
      server: {
        proxy: {
          "/api": {
            target: "http://127.0.0.1:3001",
            changeOrigin: true,
          },
        },
        allowedHosts: ['medscribe-ai-9.sd', 'localhost', '127.0.0.1'], // Add your custom domain here
      },
    };
});